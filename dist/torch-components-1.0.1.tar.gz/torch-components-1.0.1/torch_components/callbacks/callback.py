class Callback:    
    def state_dict(self) -> dict:
        pass
    
    def load_state_dict(self, state_dict:dict):
        pass