import torch


infinity = torch.tensor(float("inf"))